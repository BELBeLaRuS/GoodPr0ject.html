document.getElementById('submitBtn').addEventListener('click', function() {
    let nameInput = document.getElementById('name');
    let surnameInput = document.getElementById('surname');
    let phoneInput = document.getElementById('phone');
    
    let isValid = true;

    if (!nameInput.value.trim()) {
        nameInput.style.border = '1px solid red';
        isValid = false;
    } else {
        nameInput.style.border = '';
    }
    
    if (!surnameInput.value.trim()) {
        surnameInput.style.border = '1px solid red';
        isValid = false;
    } else {
        surnameInput.style.border = '';
    }
    
    if (!phoneInput.value.trim()) {
        phoneInput.style.border = '1px solid red';
        isValid = false;
    } else {
        phoneInput.style.border = '';
    }
});

let inputs = document.querySelectorAll('.form-control');
for (let i = 0; i < inputs.length; i++) {
    inputs[i].addEventListener('input', function() {
        if (this.value.trim()) {
            this.style.border = '';
        }
    });
};


document.getElementById('submitBtn').addEventListener('click', function() {
    let name = document.getElementById('name').value;
    let surname = document.getElementById('surname').value;
    let phone = document.getElementById('phone').value;

    let nameRegex = /^[A-Za-zА-Яа-я\s]+$/;
    let phoneRegex = /^(\+375|80)\s?\(?\d{2}\)?\s?\d{3}[\s-]?\d{2}[\s-]?\d{2}$/;

    if (!nameRegex.test(name)) {
        alert('Пожалуйста, введите корректное имя.');
        return false;
    }

    if(nameRegex.test(name) && nameRegex.test(surname) && phoneRegex.test(phone)){
        alert('Спасибо за отправленное письмо!');
    }

    if (!nameRegex.test(surname)) {
        alert('Пожалуйста, введите корректную фамилию.');
        return false;
    }

    if (!phoneRegex.test(phone)) {
        alert('Пожалуйста, введите корректный номер телефона.');
        return false;
    }

    let myModal = new bootstrap.Modal(document.getElementById('exampleModal'), {
        keyboard: false,
    });
    myModal.show();
});

    document.querySelector('.menu-toggle').addEventListener('click', function() {
    document.querySelector('header .cont').classList.toggle('active');
});