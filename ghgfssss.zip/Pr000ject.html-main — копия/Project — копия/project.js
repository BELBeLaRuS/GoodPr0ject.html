     document.querySelector('.menu-toggle').addEventListener('click', function() {
     document.querySelector('header .cont').classList.toggle('active');
});